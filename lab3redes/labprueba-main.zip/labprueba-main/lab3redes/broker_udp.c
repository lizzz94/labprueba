/*
 *
 * Para compilar usar: gcc -o broker_udp broker_udp.c
 * Luego usar: ./broker_udp
 *
 * Puertos usados:
 *   PUERTO_PUB  (8080): escucha los mensajes de los publishers
 *   PUERTO_SUB (8081): escucha los registros de los suscribers
 *
 */

#include <stdio.h>      // funciones básicas (printf, etc)
#include <stdlib.h>     // exit, malloc, etc
#include <string.h>     // manejo de strings
#include <unistd.h>     // close()
#include <sys/types.h>
#include <sys/socket.h> // sockets
#include <netinet/in.h> // estructuras de red
#include <arpa/inet.h>  // conversiones IP
#include <sys/select.h> // select (para escuchar varios sockets)

/*
 Aclaracion:
 Todas las librerias usadas son nativas de C. No se usó ninguna libreria externa.
*/

#define PUERTO_PUB 8080
#define PUERTO_SUB 8081
#define TAM_BUFFER 1024
#define MAX_SUSCRIPTORES 50
#define TAM_TEMA 64

// estructura para guardar suscriptores
typedef struct {
    struct sockaddr_in direccion;
    char tema[TAM_TEMA];
    int activo;
} Suscriptor;

static Suscriptor subs[MAX_SUSCRIPTORES];

// busca si ya existe un suscriptor
int buscar_suscriptor(struct sockaddr_in *addr, const char *tema) {
    for (int i = 0; i < MAX_SUSCRIPTORES; i++) {
        if (subs[i].activo &&
            subs[i].direccion.sin_addr.s_addr == addr->sin_addr.s_addr &&
            subs[i].direccion.sin_port == addr->sin_port &&
            strcmp(subs[i].tema, tema) == 0) {
            return i;
        }
    }
    return -1;
}

// agrega un suscriptor nuevo
void agregar_suscriptor(struct sockaddr_in *addr, const char *tema) {
    if (buscar_suscriptor(addr, tema) >= 0) return;

    for (int i = 0; i < MAX_SUSCRIPTORES; i++) {
        if (!subs[i].activo) {
            subs[i].direccion = *addr;
            subs[i].activo = 1;
            strcpy(subs[i].tema, tema);
            printf("[BROKER] nuevo suscriptor a '%s'\n", tema);
            return;
        }
    }
}

// elimina suscriptor
void eliminar_suscriptor(struct sockaddr_in *addr, const char *tema) {
    int i = buscar_suscriptor(addr, tema);
    if (i >= 0) subs[i].activo = 0;
}

// envía mensaje a todos los suscriptores del tema
void distribuir(int sock, const char *tema, const char *mensaje) {
    char salida[TAM_BUFFER];
    snprintf(salida, sizeof(salida), "%s|%s", tema, mensaje);

    for (int i = 0; i < MAX_SUSCRIPTORES; i++) {
        if (subs[i].activo && strcmp(subs[i].tema, tema) == 0) {
            sendto(sock, salida, strlen(salida), 0,
                   (struct sockaddr *)&subs[i].direccion,
                   sizeof(subs[i].direccion));
        }
    }
}

int main() {
    int sock_pub, sock_sub;
    struct sockaddr_in dir_pub, dir_sub, remitente;
    socklen_t tam;
    char buffer[TAM_BUFFER];
    fd_set fds;

    // socket para publishers
    sock_pub = socket(AF_INET, SOCK_DGRAM, 0);

    dir_pub.sin_family = AF_INET;
    dir_pub.sin_addr.s_addr = INADDR_ANY;
    dir_pub.sin_port = htons(PUERTO_PUB);

    bind(sock_pub, (struct sockaddr *)&dir_pub, sizeof(dir_pub));

    // socket para suscribers
    sock_sub = socket(AF_INET, SOCK_DGRAM, 0);

    dir_sub.sin_family = AF_INET;
    dir_sub.sin_addr.s_addr = INADDR_ANY;
    dir_sub.sin_port = htons(PUERTO_SUB);

    bind(sock_sub, (struct sockaddr *)&dir_sub, sizeof(dir_sub));

    printf("Broker listo...\n");

    while (1) {
        FD_ZERO(&fds);
        FD_SET(sock_pub, &fds);
        FD_SET(sock_sub, &fds);

        select(sock_sub + 1, &fds, NULL, NULL, NULL);

        // mensaje de publisher
        if (FD_ISSET(sock_pub, &fds)) {
            tam = sizeof(remitente);
            int n = recvfrom(sock_pub, buffer, TAM_BUFFER, 0,
                             (struct sockaddr *)&remitente, &tam);

            buffer[n] = '\0';

            char *cmd = strtok(buffer, "|");
            char *tema = strtok(NULL, "|");
            char *mensaje = strtok(NULL, "");

            if (strcmp(cmd, "PUB") == 0) {
                distribuir(sock_pub, tema, mensaje);
            }
        }

        // mensaje de suscriber
        if (FD_ISSET(sock_sub, &fds)) {
            tam = sizeof(remitente);
            int n = recvfrom(sock_sub, buffer, TAM_BUFFER, 0,
                             (struct sockaddr *)&remitente, &tam);

            buffer[n] = '\0';

            char *cmd = strtok(buffer, "|");
            char *tema = strtok(NULL, "");

            if (strcmp(cmd, "SUB") == 0) {
                agregar_suscriptor(&remitente, tema);
            } else if (strcmp(cmd, "UNSUB") == 0) {
                eliminar_suscriptor(&remitente, tema);
            }
        }
    }
}