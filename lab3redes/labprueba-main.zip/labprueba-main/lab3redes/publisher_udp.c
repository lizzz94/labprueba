/*
 * publisher_udp.c
 *
 * Para compilar usar: gcc -o publisher_udp publisher_udp.c
 * Ejemplo:  ./publisher_udp 127.0.0.1 "ColombiaVsFrancia"
 *
 */

#include <stdio.h>      // printf, fgets
#include <stdlib.h>     // exit
#include <string.h>     // strings
#include <unistd.h>     // close
#include <sys/types.h>
#include <sys/socket.h> // sockets
#include <netinet/in.h>
#include <arpa/inet.h>

/*
 Aclaracion:
Todas las librerias usadas son nativas de C. No se usó ninguna libreria externa.
*/

#define PUERTO_BROKER 8080
#define TAM_BUFFER 1024

int main(int argc, char *argv[]) {
    int socket_envio;
    struct sockaddr_in direccion_broker;

    char entrada_usuario[TAM_BUFFER];   // lo que escribe el usuario
    char mensaje_final[TAM_BUFFER];     // lo que realmente se envía

    int bytes_enviados;
    int contador_mensajes = 0;

    // validar argumentos
    if (argc < 3) {
        fprintf(stderr, "Uso: %s <ip_broker> <tema>\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    const char *ip_broker = argv[1];
    const char *tema = argv[2];

    // crear socket UDP
    socket_envio = socket(AF_INET, SOCK_DGRAM, 0);
    if (socket_envio < 0) {
        perror("socket");
        exit(EXIT_FAILURE);
    }

    // configurar dirección del broker
    memset(&direccion_broker, 0, sizeof(direccion_broker));
    direccion_broker.sin_family = AF_INET;
    direccion_broker.sin_port = htons(PUERTO_BROKER);
    direccion_broker.sin_addr.s_addr = inet_addr(ip_broker);

    if (direccion_broker.sin_addr.s_addr == (in_addr_t)-1) {
        printf("IP inválida\n");
        close(socket_envio);
        exit(EXIT_FAILURE);
    }

    // bucle principal
    while (1) {
        printf("[MSG #%d] > ", contador_mensajes + 1);
        fflush(stdout);

        // leer mensaje
        if (fgets(entrada_usuario, sizeof(entrada_usuario), stdin) == NULL)
            break;

        // quitar salto de línea
        entrada_usuario[strcspn(entrada_usuario, "\n")] = '\0';

        if (strlen(entrada_usuario) == 0)
            continue;

        // armar mensaje tipo: PUB|tema|contenido
        // le agregamos número para poder detectar pérdidas
        snprintf(mensaje_final, sizeof(mensaje_final),
                 "PUB|%s|[%d] %s",
                 tema, contador_mensajes + 1, entrada_usuario);

        // enviar mensaje al broker
        bytes_enviados = sendto(socket_envio,
                               mensaje_final,
                               strlen(mensaje_final),
                               0,
                               (struct sockaddr *)&direccion_broker,
                               sizeof(direccion_broker));

        if (bytes_enviados >= 0)
            contador_mensajes++;
    }

    close(socket_envio);
    return 0;
}