/*
 * suscriber_udp.c
 * Para compilar usar: suscriber_udp.c -o suscriber
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

/*
 Aclaracion:
 Todas las librerias usadas son nativas de C. No se usó ninguna libreria externa.
*/

#define PUERTO_BROKER 8081
#define PUERTO_LOCAL 9000
#define TAM_BUFFER 1024
#define MAX_TEMAS 20
#define TAM_TEMA 64

// variables globales para poder manejar CTRL+C
static int socket_registro = -1;
static char ip_broker[64];
static char temas[MAX_TEMAS][TAM_TEMA];
static int cantidad_temas = 0;
static int ejecutando = 1;

// envía SUB o UNSUB al broker
void enviar_comando(int sock, struct sockaddr_in *dir_broker,
                    const char *comando, const char *tema) {

    char mensaje[TAM_BUFFER];

    snprintf(mensaje, sizeof(mensaje), "%s|%s", comando, tema);

    sendto(sock,
           mensaje,
           strlen(mensaje),
           0,
           (struct sockaddr *)dir_broker,
           sizeof(*dir_broker));
}

// cuando haces CTRL+C cancela suscripciones
void manejar_senal(int signo) {
    struct sockaddr_in dir_broker;

    memset(&dir_broker, 0, sizeof(dir_broker));
    dir_broker.sin_family = AF_INET;
    dir_broker.sin_port = htons(PUERTO_BROKER);
    dir_broker.sin_addr.s_addr = inet_addr(ip_broker);

    // manda UNSUB de todos los temas
    for (int i = 0; i < cantidad_temas; i++) {
        enviar_comando(socket_registro, &dir_broker, "UNSUB", temas[i]);
    }

    ejecutando = 0;
}

int main(int argc, char *argv[]) {
    int socket_escucha;
    struct sockaddr_in dir_local, dir_broker, remitente;

    socklen_t tam;
    char buffer[TAM_BUFFER];
    int n;

    if (argc < 3) {
        printf("Uso: %s <ip_broker> <tema1> ...\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    strncpy(ip_broker, argv[1], sizeof(ip_broker) - 1);

    // guardar temas
    cantidad_temas = argc - 2;
    for (int i = 0; i < cantidad_temas; i++) {
        strncpy(temas[i], argv[2 + i], TAM_TEMA - 1);
    }

    // capturar CTRL+C
    signal(SIGINT, manejar_senal);

    // socket para enviar comandos
    socket_registro = socket(AF_INET, SOCK_DGRAM, 0);

    memset(&dir_broker, 0, sizeof(dir_broker));
    dir_broker.sin_family = AF_INET;
    dir_broker.sin_port = htons(PUERTO_BROKER);
    dir_broker.sin_addr.s_addr = inet_addr(ip_broker);

    // socket para recibir mensajes
    socket_escucha = socket(AF_INET, SOCK_DGRAM, 0);

    memset(&dir_local, 0, sizeof(dir_local));
    dir_local.sin_family = AF_INET;
    dir_local.sin_addr.s_addr = INADDR_ANY;
    dir_local.sin_port = htons(PUERTO_LOCAL);

    bind(socket_escucha, (struct sockaddr *)&dir_local, sizeof(dir_local));

    // enviar SUB por cada tema
    for (int i = 0; i < cantidad_temas; i++) {
        char mensaje[TAM_BUFFER];
        snprintf(mensaje, sizeof(mensaje), "SUB|%s", temas[i]);

        sendto(socket_escucha,
               mensaje,
               strlen(mensaje),
               0,
               (struct sockaddr *)&dir_broker,
               sizeof(dir_broker));
    }

    printf("Esperando mensajes...\n");

    // recibir mensajes
    while (ejecutando) {
        tam = sizeof(remitente);

        n = recvfrom(socket_escucha,
                     buffer,
                     sizeof(buffer) - 1,
                     0,
                     (struct sockaddr *)&remitente,
                     &tam);

        if (n < 0) continue;

        buffer[n] = '\0';

        // separar tema y mensaje
        char *tema = strtok(buffer, "|");
        char *mensaje = strtok(NULL, "");

        if (tema && mensaje) {
            printf("[%s] %s\n", tema, mensaje);
        }
    }

    close(socket_registro);
    close(socket_escucha);
    return 0;
}